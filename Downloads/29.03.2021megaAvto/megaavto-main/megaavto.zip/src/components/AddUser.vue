<!-- @format -->

<template>
  <div class="admin-content new-user">
    <div class="container reg">
      <div class="row">
        <div class="col-lg-4 col-md-6 col-sm-8 mx-auto">
          <div class="card register">
            <div class="card_header">
              <h3>Новый пользователь</h3>
            </div>
            <form class="form-group mb-0">
              <input
                v-model="userRegister.first_name"
                class="form-control mb-2"
                type="text"
                placeholder="Имя"
                :class="{
                  'is-invalid':
                    registerSubmitted && $v.userRegister.first_name.$error,
                }"
              />
              <div
                v-if="registerSubmitted && $v.userRegister.first_name.$error"
                class="invalid-feedback"
              >
                <span v-if="!$v.userRegister.first_name.required"
                  >Введите имя</span
                >
              </div>
              <input
                v-model="userRegister.last_name"
                class="form-control mb-2"
                placeholder="Фамилия"
                :class="{
                  'is-invalid':
                    registerSubmitted && $v.userRegister.last_name.$error,
                }"
              />
              <div
                v-if="registerSubmitted && $v.userRegister.last_name.$error"
                class="invalid-feedback"
              >
                <span v-if="!$v.userRegister.last_name.required"
                  >Введите Фамилию</span
                >
              </div>
              <input
                class="form-control mb-2"
                placeholder="Имя пользователя"
                v-model="userRegister.username"
                :class="{
                  'is-invalid':
                    registerSubmitted && $v.userRegister.username.$error,
                }"
              />
              <div
                v-if="registerSubmitted && $v.userRegister.username.$error"
                class="invalid-feedback"
              >
                <span v-if="!$v.userRegister.username.required"
                  >Введите имя пользователя</span
                >
              </div>
              <input
                class="form-control mb-2"
                placeholder="Телефон"
                v-model="userRegister.phone"
                v-mask="'+38(###)###-##-##'"
                :class="{
                  'is-invalid':
                    registerSubmitted && $v.userRegister.phone.$error,
                }"
              />
              <div
                v-if="registerSubmitted && $v.userRegister.phone.$error"
                class="invalid-feedback"
              >
                <span v-if="!$v.userRegister.phone.required"
                  >Введите телефон</span
                >
                <span v-if="!$v.userRegister.phone.minLength"
                  >Введите телефон полностью</span
                >
              </div>
              <input
                v-model="userRegister.email"
                type="email"
                class="form-control mb-2"
                placeholder="Email"
                style="font-size: 14px"
                required
                :class="{
                  'is-invalid':
                    registerSubmitted && $v.userRegister.email.$error,
                }"
              />
              <div
                v-if="registerSubmitted && $v.userRegister.email.$error"
                class="invalid-feedback"
              >
                <span v-if="!$v.userRegister.email.required"
                  >Введите почту</span
                >
                <span v-if="!$v.userRegister.email.email"
                  >Не правильная почта</span
                >
              </div>
              <input
                v-model="userRegister.password"
                type="password"
                class="form-control mb-2"
                placeholder="Пароль"
                style="font-size: 14px"
                required
                :class="{
                  'is-invalid':
                    registerSubmitted && $v.userRegister.password.$error,
                }"
              />
              <div
                v-if="registerSubmitted && $v.userRegister.password.$error"
                class="invalid-feedback"
              >
                <span v-if="!$v.userRegister.password.required"
                  >Введите пароль</span
                >
              </div>
              <input
                v-model="userRegister.confirm"
                type="password"
                class="form-control mb-5"
                placeholder="Повторите пароль"
                style="font-size: 14px"
                required
                :class="{
                  'is-invalid':
                    registerSubmitted && $v.userRegister.confirm.$error,
                }"
              />
              <div
                v-if="registerSubmitted && $v.userRegister.confirm.$error"
                class="invalid-feedback"
              >
                <span v-if="!$v.userRegister.confirm.required"
                  >Повторите пароль</span
                >
              </div>
              <div
                v-if="userRegister.password !== userRegister.confirm"
                class="confirm_error"
              >
                Пароли не совпадают
              </div>
              <v-btn
                class=" mb-4"
                @click="registration"
                style="
                  color: white;
                  background-color: orange;
                  font-weight: 800;
                  border: 1px solid darkorange;
                  padding: 5px;
                "
                >Добавить пользователя</v-btn
              >
            </form>
          </div>
          <v-col
            cols="12"
            :class="
              getNotification.active
                ? ' d-flex justify-content-center alert-notification alert-notification-active'
                : 'd-flex justify-content-center alert-notification alert-notification-unactive'
            "
          >
            <v-alert type="success">{{ getNotification.message }}</v-alert>
          </v-col>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { required, minLength, email } from "vuelidate/lib/validators";
import { mask } from "vue-the-mask";

export default {
  name: "AddUser",
  directives: { mask },
  computed: {
    isLoggedIn() {
      return this.$store.getters.isLoggedIn;
    },
    getNotification() {
      return this.$store.getters.getNotification;
    },
    isAdmin() {
      return this.$store.getters.isAdmin;
    },
  },
  beforeMount() {
    if (!this.isAdmin) {
      this.$router.push("/admin");
    }
  },
  data() {
    return {
      userRegister: {
        first_name: "",
        last_name: "",
        username: "",
        phone: "",
        email: "",
        password: "",
        confirm: "",
      },
      registerActive: false,
      emptyFields: false,
      registerSubmitted: false,
    };
  },
  validations: {
    userRegister: {
      first_name: { required },
      last_name: { required },
      username: { required },
      phone: { required, minLength: minLength(17) },
      email: { required, email },
      password: { required },
      confirm: { required },
    },
  },
  methods: {
    async registration() {
      this.registerSubmitted = true;
      console.log("hey2");

      // stop here if form is invalid
      this.$v.$touch();
      if (this.$v.$invalid) {
        console.log("reg error");
        return;
      }
      console.log("hey");
      await this.$store.dispatch("addNewUser", {
        first_name: this.userRegister.first_name,
        last_name: this.userRegister.last_name,
        username: this.userRegister.username,
        phone: this.userRegister.phone,
        email: this.userRegister.email,
        password: this.userRegister.password,
      });
    },
  },
};
</script>

<style lang="scss">
.new-user {
  position: relative;
  z-index: 200;
}
.reg {
  margin-top: 150px;
}
</style>
