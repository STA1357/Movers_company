<!-- @format -->

<template>
  <div class="myNav">
    <v-app-bar
      class="nav-color"
      color=" navbar-main"
      dense
      dark
      style="height: 64px"
    >
      <!-- <v-app-bar-nav-icon></v-app-bar-nav-icon> -->

      <v-toolbar-title style="margin-top: 20px">
        <router-link
          class="router-link"
          to="/"
          style="color: #f69e30; font-weight: 600;"
          ><b>M</b>ega<b>A</b>vto
        </router-link>
      </v-toolbar-title>

      <v-spacer></v-spacer>

      <v-btn
        v-if="!isLoggedIn"
        class="btn-about"
        style="color: #f69e30; font-weight:600; height: 34px; border-radius: 15px;
                margin: 12px 25px 0 0; background: none;"
        >О нас</v-btn
      >
      <v-btn
        v-if="!isLoggedIn"
        class="btn-about"
        style="color: #f69e30; font-weight:600; height: 34px; border-radius: 15px;
                margin: 12px 25px 0 0; background: none;"
        >Контакты</v-btn
      >

      <v-btn
        style="opacity: 1 !important; outline: none !important;"
        plain
        v-if="!isLoggedIn"
        class="button-enter"
        to="/login"
        ><span class="span_two">Войти в кабинет</span
        ><span class="span_one">Войти</span></v-btn
      >
      <v-btn v-if="isLoggedIn" depressed :ripple="false" class="pro-plan-btn"
        >Pro Plan</v-btn
      >
      <div v-if="isLoggedIn" class="user-name-navbar">
        <v-img
          max-width="20"
          max-height="20"
          src="../assets/icons/bell.png"
          class="mr-3"
        ></v-img>
        {{ getUser.first_name + " " + getUser.last_name }}
      </div>
      <v-img
        v-if="isLoggedIn"
        class="navbar-user-img mt-4"
        lazy-src="https://picsum.photos/id/11/10/6"
        max-height="60"
        max-width="60"
        width="60"
        height="60"
        :src="getUser.image"
      ></v-img>
      <v-menu v-if="isLoggedIn" left bottoms>
        <template v-slot:activator="{ on, attrs }">
          <v-btn icon v-bind="attrs" v-on="on" class="navbar-user__menu">
            <v-img
              src="../assets/icons/arrow-down.svg"
              max-width="14"
              max-height="7"
              class="mt-3"
            ></v-img>
          </v-btn>
        </template>
        <v-list>
          <v-list-item>
            <v-btn
              depressed
              :ripple="false"
              plain
              color="#2C5282"
              class="link-btn-navbar mt-3"
              active-class="active-link-btn-navbar"
              to="/admin/profile"
            >
              Профиль</v-btn
            >
          </v-list-item>
          <v-list-item>
            <v-btn
              depressed
              plain
              :ripple="false"
              class="  link-btn-navbar mt-3"
              active-class="active-link-btn-navbar"
              color="#2C5282"
              @click="logout"
              >Выход</v-btn
            >
          </v-list-item>
        </v-list>
      </v-menu>
      <v-app-bar-nav-icon
        v-if="isLoggedIn"
        :ripple="false"
        class="mobile-btn mt-3"
        @click="openSidebar"
        color="#EF9E30"
      ></v-app-bar-nav-icon>
    </v-app-bar>
  </div>
</template>

<script>
import { mapGetters } from "vuex";

export default {
  components: {},
  computed: mapGetters(["isLoggedIn", "getUser"]),
  methods: {
    async logout() {
      this.$store.dispatch("logout");
      this.$router.push("/");
    },
    openSidebar() {
      this.$store.dispatch("changeSidebar");
    },
  },
  mounted() {
    console.log(this.getUser);
    console.log(this.isLoggedIn);
  },
};
</script>

<style lang="scss" scoped>
.navbar-user__menu {
  @media (max-width: 960px) {
    display: none !important;
  }
}
.user-name-navbar {
  display: flex;
  font-family: Roboto;
  font-style: normal;
  font-weight: normal;
  font-size: 18px;
  line-height: 21px;
  color: #2c5282;
  padding-right: 20px;
  padding-top: 15px;
  @media (max-width: 960px) {
    display: none;
  }
}
.navbar-user-img {
  border: 5px solid #f2994a;
  border-radius: 50%;
  @media (max-width: 960px) {
    display: none;
  }
}
.mobile-btn {
  @media (min-width: 960px) {
    display: none;
  }
}
.v-btn--plain.v-btn__content {
  opacity: 1 !important;
}

.span_one {
  display: block;
  padding-top: 1px;
}
.span_two {
  display: none;
  padding-top: 1px;
}

.button-enter {
  background: linear-gradient(180deg, #f2994a 0%, #ff7a7a 100%) !important;
  color: white !important;
  opacity: 1 !important;
  font-weight: 600;
  height: 34px;
  border-radius: 15px;
  margin-top: 12px;
  text-transform: capitalize !important;
}

.g > div {
  background: #fff;
}

@media screen and (max-width: 960px) {
  .span_one {
    display: none;
  }
  .span_two {
    display: block;
  }
  .btn-about{
    display: none !important;
  }
}


.router-link {
  color: #fff;
  text-decoration: none;
}
.btn-about {
  position: relative;
  color: white;
  text-decoration: none;
  display: inline-block;
  align-items: center;
  text-transform: uppercase;
  letter-spacing: 1px;
  border-top: 2px solid #f2994a;
  border-bottom: 2px solid #ff7a7a;
  border-left: 2px solid #f2994a;
  border-right: 2px solid #ff7a7a;
  border-radius: 1000px;
  padding: 0 50px !important;
  margin: 40px;
  box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
  transition: 0.5s all ease-in-out;
  &:hover {
    cursor: pointer;
    background: linear-gradient(180deg, #f2994a 0%, #ff7a7a 100%) !important;
    color: white !important;
    animation: none;
    //animation-play-state: paused;
  }
}
.navbar-main {
  position: relative;
  z-index: 100;
}
.nav-color {
  background-color: white !important;
  position: fixed;
}
b {
  color: #2c3e50;
  font-weight: 600;
}
.button-pulse {
  animation: pulse 3s infinite 3s cubic-bezier(0.25, 0, 0, 1);
  box-shadow: 0 0 0 0 orange;
}
@keyframes pulse {
  to {
    box-shadow: 0 0 0 18px rgba(255, 255, 255, 0);
  }
}
.link-btn-navbar {
  display: flex;
  justify-content: flex-start;
  font-weight: normal;
  text-transform: capitalize;
  font-size: 14px !important;
  border: 1px black;
  width: 160px !important;
  padding: 0 !important;
  margin-right: 0 !important;
  margin-left: 0 !important;
  text-decoration: none;
  &:not(:focus):not(:hover) {
    opacity: 1 !important;
  }
}
.active-link-btn-navbar {
  font-weight: 900;
}
.pro-plan-btn {
  text-transform: capitalize;
  background: linear-gradient(180deg, #f2994a 0%, #ff7a7a 100%);
  font-family: Roboto;
  font-style: normal;
  font-weight: bold;
  font-size: 12px;
  line-height: 14px;
  color: #fffcfe;
  margin-top: 14px;
  margin-right: 25px;
  @media (max-width: 960px) {
    display: none;
  }
}
</style>
